%		T-MATS -- setup_Bus.m
% *************************************************************************
% written by Jeffyres Chapman
% NASA Glenn Research Center, Cleveland, OH
% Dec 19th, 2012
%
% This function loads the Buses for the Plant Template.
% *************************************************************************


load Solver_Bus.mat
