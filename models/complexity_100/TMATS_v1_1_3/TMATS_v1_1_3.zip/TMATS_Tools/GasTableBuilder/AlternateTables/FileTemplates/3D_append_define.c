    double tg; 
    int interpErr = 0;
    double zi, yi, xi;
	double inc_X, inc_Y, inc_Z;
	int ii, jj, kk;
	int i, j, k;
	int Lxy;
	double v000, v100, v010, v001, v101, v011, v110, v111;
	double P;
	double xx, yy, zz;
	
	int errValue = 0;
    