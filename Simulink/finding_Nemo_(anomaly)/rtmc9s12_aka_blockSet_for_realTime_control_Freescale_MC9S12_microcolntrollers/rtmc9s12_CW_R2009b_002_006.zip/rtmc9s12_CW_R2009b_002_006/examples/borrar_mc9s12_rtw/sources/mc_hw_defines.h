/* automatically generated defines      */
/* 04-Sep-2010 14:44:01                 */

#ifndef _MC_HW_DEFINES_H_
#define _MC_HW_DEFINES_H_

/* hardware selection and debugging */
#define                   TARGET_BOARD   BSP_DRAGON12PLUS
#define              TARGET_OSCILLATOR   8
#define                     TARGET_CPU   BSP_MC9S12DG256
#define              TARGET_CPU_FAMILY   BSP_MC9S12
#define                  DEBUG_MSG_LVL   0
#define                 DEBUG_MSG_MNGL   0


#endif /* _MC_HW_DEFINES_H_ */
