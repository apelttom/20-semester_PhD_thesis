function RunCTB()
% T-MATS -- RunCTB.m
% *************************************************************************
% written by Jeffryes Chapman 
% NASA Glenn Research Center, Cleveland, OH
% May 22th, 2014
%
% For information on operation see README.txt

CanteraTableBuilder
