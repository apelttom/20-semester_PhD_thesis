%Run T-MATS data viewer GUI 

run('DViewerGUI_TMATS')
