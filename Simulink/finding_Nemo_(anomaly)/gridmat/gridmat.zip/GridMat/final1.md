[Feeder]
4
[House Type]
{type1}
house,constant_admittance,1.000000
dryer,voltage_factor,2.000000
{type2}
house,constant_admittance,3.000000
waterheater,voltage_factor,4.000000
[Topology]
topology
[Scheduler]
sh1
sh2
sh3
sh4
[Player]
pl1
pl2
pl3
pl4
pl6
[Simulation Start]
start time
[Simulation Stop]
sttop time
[Interval]
10
[Transformer]
1
[House]
1
[Average]
1
[Accumulate]
1
[Weather]
weather1
[House Selection]
0
