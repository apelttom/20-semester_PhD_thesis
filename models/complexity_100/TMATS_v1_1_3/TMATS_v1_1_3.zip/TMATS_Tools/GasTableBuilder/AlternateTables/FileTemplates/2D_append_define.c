    double tg; 
    int interpErr = 0;
    double zi, yi, xi;
	double inc_X, inc_Y, inc_Z;
	int ii, jj;
	int i, j;
	int Lxy;
	double v00, v10, v01, v11, P;
	double xx, yy, zz;
	
	int errValue = 0;
    