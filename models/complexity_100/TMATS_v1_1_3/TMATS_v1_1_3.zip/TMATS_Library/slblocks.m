function blkStruct = slblocks
  % Specify that the product should appear in the library browser
  % and be cached in its repository
  Browser.Library = 'TMATS_Lib';
  Browser.Name    = 'T-MATS';
  blkStruct.Browser = Browser;